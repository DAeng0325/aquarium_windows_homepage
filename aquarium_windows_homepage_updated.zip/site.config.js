
module.exports = {
  rootNotionPageId: '1d39a1da12a98083afa5f3cc3618b829',
  rootNotionSpaceId: null,
  name: 'Echoes Aquarium',
  domain: 'www.no-one-lives-here-but-echoes-404.pe.kr',
  author: 'Echo User',
  description: 'This is a retro CRT-style aquarium-themed website using Notion as CMS.',
  socialImageTitle: 'Echoes Aquarium',
  socialImageSubtitle: 'no-one-lives-here-but-echoes-404',
  defaultPageIcon: null,
  defaultPageCover: null,
  defaultPageCoverPosition: 0.5,
  isPreviewImageSupportEnabled: true,
  isRedisEnabled: false,
  pageUrlOverrides: null,
  navigationStyle: 'default',
}
