
/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  images: {
    domains: ['www.notion.so', 'www.no-one-lives-here-but-echoes-404.pe.kr']
  }
}

module.exports = nextConfig
